using Unity.VisualScripting;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    //Ʈ���� ī��
    public GameObject trumpGroup;
    public GameObject trumpPrefab;
    public GameObject[] trumpObjects;
    public TrumpCard[] trumpCardScript;

    //ä��Ĺ
    public GameObject cheshireCatGroup;
    public GameObject cheshireCatPrefab;
    public GameObject[] cheshireCatObjects;
    public CheshireCatClaw[] cheshireCatScript;

    //�Ȼ��� ���� ����
    public GameObject firecrackerGroup;
    public GameObject firecrackerPrefab;
    public GameObject[] firecrackerObjects;
    public NonBirthdayFirecracker[] firecrackerScript;

    //���
    public GameObject appleGroup;
    public GameObject applePrefab;
    public GameObject[] appleObjects;
    public RollApple[] appleScript;

    private void Awake()
    {
        //Ʈ���� Ǯ��
        for (int i = 0; i < trumpObjects.Length; i++)
        {
            GameObject trumpObj = Instantiate(trumpPrefab);
            trumpObj.transform.parent = trumpGroup.transform;
            trumpObjects[i] = trumpObj;
            trumpCardScript[i] = trumpObjects[i].GetComponent<TrumpCard>();
            trumpObj.SetActive(false);
        }

        //ä��Ĺ Ǯ��
        for (int i = 0; i < trumpObjects.Length; i++)
        {
            GameObject cheshireCatObj = Instantiate(cheshireCatPrefab);
            cheshireCatObj.transform.parent = cheshireCatGroup.transform;
            cheshireCatObjects[i] = cheshireCatObj;
            cheshireCatScript[i] = cheshireCatObjects[i].GetComponent<CheshireCatClaw>();
            cheshireCatObj.SetActive(false);
        }

        //�Ȼ��� ���� ���� Ǯ��
        for (int i = 0; i < firecrackerObjects.Length; i++)
        {
            GameObject firecrackerObj = Instantiate(firecrackerPrefab);
            firecrackerObj.transform.parent = firecrackerGroup.transform;
            firecrackerObjects[i] = firecrackerObj;
            firecrackerScript[i] = firecrackerObjects[i].GetComponent<NonBirthdayFirecracker>();
            firecrackerObj.SetActive(false);
        }

        //��� Ǯ��
        for (int i = 0; i < appleObjects.Length; i++)
        {
            GameObject appleObj = Instantiate(applePrefab);
            appleObj.transform.parent = appleGroup.transform;
            appleObjects[i] = appleObj;
            appleScript[i] = appleObjects[i].GetComponent<RollApple>();
            appleObj.SetActive(false);
        }
    }
    private void Start()
    {

    }
}
