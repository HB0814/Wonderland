using UnityEngine;

public class TrumpCardThrow : MonoBehaviour
{
    [SerializeField]
    TrumpCard trumpCard;

    float projectileSpeed = 15.0f;
    bool isAttack = false;

    private void OnBecameInvisible()
    {
        transform.rotation = Quaternion.Euler(0, 0, 0);
        transform.position = Vector3.zero;
        trumpCard.isAttack = false;
        trumpCard.timer = 0.0f;
    }
}
