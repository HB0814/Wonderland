public interface IPooledObject
{
    void OnObjectSpawn();
} 