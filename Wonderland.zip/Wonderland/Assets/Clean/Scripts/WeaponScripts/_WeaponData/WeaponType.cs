public enum WeaponType
{
    None,
    Firecracker,
    Pipe,
    Sword,
    Hat,
    Cat,
    Watch,
    Book,
    Apple,
    Tea,
    Card
} 