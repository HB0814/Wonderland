using UnityEngine;

public class MeleeEnemy : Enemy
{
    protected override void Update()
    {
        base.Update();
    }
} 