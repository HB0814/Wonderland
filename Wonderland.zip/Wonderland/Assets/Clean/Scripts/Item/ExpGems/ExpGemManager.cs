using System.Collections.Generic;
using UnityEngine;

public class ExpGemManager : MonoBehaviour
{
    //public static ExpGemManager Instance;
    //public List<ExpGem> activeGems = new();

    //private void Awake()
    //{
    //    Instance = this;
    //}

    //public void Register(ExpGem gem)
    //{
    //    activeGems.Add(gem);
    //}

    //public void Unregister(ExpGem gem)
    //{
    //    activeGems.Remove(gem);
    //}

    //public void AttractAll()
    //{
    //    foreach (ExpGem gem in activeGems)
    //    {
    //        gem.StartAttraction();
    //    }
    //}
}
